#include<bits/stdc++.h>


using namespace std;


int main(){

string s;
getline(cin,s);
vector<string>ss;
int i,n,c=0;



string temp="";
map<string,int>smap;
for (int i=0;i<s.size();i++){
if (s[i]==' '|| s[i]=='.'||s[i]==','){
ss.push_back(temp);
c++;
temp="";
}
else temp +=s[i];
}
ss.push_back(temp);


for (int i=0;i<ss.size();i++){
map<string,int>::iterator it = smap.find(ss[i]);
if (it!=smap.end()){
it->second++;}
else{
smap.insert(pair<string,int>(ss[i],1));}
}
for (auto it = smap.begin();it!=smap.end();it++)
cout<<it->first<<" "<<it->second<<endl;
return 0;


}

































































































































































