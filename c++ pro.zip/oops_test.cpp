#include<bits/stdc++.h>
using namespace std;

class A {
//static int x;
	public :
		static int x;
	   A(){
		   x++;
	   }
};
int A::x=0;

int main(){
	A a,b;
	A c,d,e;

	cout<<A::x<<endl;



	return 0;
}
