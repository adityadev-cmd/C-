
#include<bits/stdc++.h>
using namespace std;
				/////doubly linked list////
struct Node {
	int data;
	struct Node*prev;
	struct Node*next;
};

void  pussh(struct Node **head, int node){
	struct Node* last = *head;
	struct Node* new_node = (struct Node*)malloc(sizeof(struct Node));
	new_node->data = node;
	new_node->next = NULL;

	if (*head == NULL){
		new_node->prev = NULL;
		*head = new_node;
		return;
	}

	/// already present 
	
	 while(last->next !=NULL)
		 last = last->next;

	 last->next = new_node;
	 new_node->prev = last;
	 return;
		
}

void printlist(struct Node *node){
	struct Node* last;
	while( node!=NULL){
		printf("%d ",node->data);
		last =node;
		node = node->next;
	}
	while(last != NULL){
		printf("%d ",node->data);
		last =last->prev;

	}

}
void del(struct Node *head){
	struct Node *last;
	while(last->next->next!=NULL)
		last =last->next;
	last->next=NULL;
	last=last->next;
	last->prev = NULL;
}





int main(){
	int n,a;
//	cin>>n;
	struct Node* head = NULL;

//	for (int i=0;i<n;i++){
//		cin>>a;
		pussh(&head,5);
		pussh(&head,4);
		
		pussh(&head,3);
		pussh(&head,2);
		pussh(&head,1);


//	}

///print //// 
 	printlist(head);
	return 0;
}





