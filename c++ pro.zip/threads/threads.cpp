#include<bits/stdc++.h>
using namespace std;
using namespace std::chrono;
typedef unsigned long long ull;

ull even =0;
ull odd = 0;

void findeven(ull start , ull end){
	for (int i=start;i<end;i++){
		if ((i&1)==0)
			even +=i;
	}
}

void findodd(ull start,ull end){
	for (int i=start;i<end;i++){
		if (i&1==1)
			odd += i;
	}
   
}


int main(){
	ull start =0 ,end = 19000000;
	
	auto startTime = high_resolution_clock::now();
	
	std::thread t1(findeven,start,end);
	std::thread t2(findodd,start,end);

	t1.join();
	t2.join();

//	findeven(start,end);
//	findodd(start,end);

	auto stopTime = high_resolution_clock::now();
	auto duration = duration_cast<microseconds>(stopTime - startTime);
	cout<<"Evensum  "<<even<<endl;
	cout<<"Oddsum   "<<odd<<endl;
	cout<<"Secs  "<<duration.count()/1000000 <<endl;
	return 0;
}


