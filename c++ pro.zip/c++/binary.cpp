#include<bits/stdc++.h>
using namespace std;

int main(){
	int a[8]= {000,001,010,011,100,101,110,111};
	for(int i=0;i<8;i++)
		printf("%d  ",a[i]);

	return 0;
}
