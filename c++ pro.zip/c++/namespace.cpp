#include <bits/stdc++.h>
using namespace std;

namespace first {
	int value(){
		return 100;}
}

int value  =1000;

int main(){
 int value = 200;

  cout<<"inside class "<<value <<endl;
  cout<<"global vali value "<<value<<endl;
  cout<<"namespace vali value "<< first::value()<<endl;



	return 0;
}
