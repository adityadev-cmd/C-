#include <bits/stdc++.h> 

// Definition of print function is 
// present in function.h file 
#include "function.h" 
using namespace std; 

void print() 
{ 
	cout << "makefile" << endl; 
} 

