#include <bits/stdc++.h> 

// Definition of multiply function 
// is present in function.h file 
#include "function.h" 
using namespace std; 

int multiply(int a, int b) 
{ 
	return a * b; 
} 

