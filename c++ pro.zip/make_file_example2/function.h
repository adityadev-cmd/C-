#ifndef FUNCTIONS_H 
#define FUNCTIONS_H 
  
void print(); 
int factorial(int); 
int multiply(int, int); 
  
#endif 
