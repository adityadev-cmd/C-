#include <bits/stdc++.h> 

// Note function.h which has all functions 
// definations has been included 
#include "function.h" 

using namespace std; 

// Main program 
int main() 
{ 
	int num1 = 1; 
	int num2 = 2; 
	cout << multiply(num1, num2) << endl; 
	int num3 = 5; 
	cout << factorial(num3) << endl; 
	print(); 
} 

