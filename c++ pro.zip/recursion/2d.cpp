#include<bits/stdc++.h>
using namespace std;
#define n 4
void addition(int a[][n],int b[][n], int add[][n]){
	int i,j,sum=0;
	for(i=0;i<n;i++){
	       for (j=0;j<n;j++){
	       add[i][j]= a[i][j]+b[i][j];
	      // cout<<sum<<" ";
	       }
	      // cout<<endl;
	}
}
void multiply(int a[][n],int b[][n],int mul[][n]){
	for (int i=0;i<n;i++){
		for (int j=0;j<n;j++){
			mul[i][j]=0;
			for (int k=0;k<n;k++)
				mul[i][j]= a[i][k]*b[k][j];
		}
	}
}
void transpose(int a[][n], int trans[][n]){
	for(int i=0;i<n;i++){
		for (int j=0;j<n;j++){
			trans[i][j] = a[j][i];
		}
	}
}

int main(){
//	int n,m,k,l;
//	cin>n>>m;
	int a[n][n]={0};
	for (int i=0;i<n;i++){
		for (int j=0;j<n;j++)
			cin>>a[i][j];
	}

	int b[n][n]={0};
	for (int i=0;i<n;i++){
		for (int j=0;j<n;j++)
			cin>>b[i][j];
	}
	int add[n][n]={0},mul[n][n]={0},trans[n][n]={0};

	addition(a,b,add);
	multiply(a,b,mul);
	transpose(a,trans);
	cout<<"addition"<<endl;
	for (int i=0;i<n;i++){
		for (int j=0;j<n;j++)
			cout<<add[i][j]<<" ";
		cout<<endl;
	}
	
	cout<<"multiplication"<<endl;
	for (int i=0;i<n;i++){
		for (int j=0;j<n;j++)
			cout<<mul[i][j]<<" ";
		cout<<endl;
	}

	cout<<"transpose"<<endl;

	for (int i=0;i<n;i++){
		for (int j=0;j<n;j++)
			cout<<trans[i][j];
		cout<<endl;
	}

	return 0;
	}

