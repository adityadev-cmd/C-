#include<bits/stdc++.h>
using namespace std;
#define NDEBUG
int main(){
	int x=7;
	assert(x==0);
	cout<<"true";
	return 0;
}
