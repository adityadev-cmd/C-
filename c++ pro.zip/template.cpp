#include<bits/stdc++.h>
using namespace std;

template <typename T>
struct link {
	T data;
	link *next;
};

template <class T>
class linklist  {
	private :
		link<T>*first;
	public:
		linklist(){
			first =NULL;}
		void additem(T d);
		void display();
};

template <class T>
void linklist<T>::display(){
	link<T>*cur = first;
	while(cur!=NULL){
	cout<<cur->data<<" ";
	cur = cur ->next;
	}
}

template<class T>
void linklist<T>::additem(T d){
	link<T>*newlink = new link<T>;
	newlink->data = d;
	newlink->next =first;
	first = newlink;
}

int main(){
	linklist<int>li;
	li.additem(25);
	
	li.additem(5);
	li.additem(20);
	li.additem(2);

	li.display();

	linklist<char>l;
	l.additem('a');
	l.additem('b');
	l.additem('c');
	l.additem('d');

	l.display();
}
