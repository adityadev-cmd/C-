void fun(void);

