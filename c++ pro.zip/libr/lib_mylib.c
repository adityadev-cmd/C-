#include<stdio.h>
void fun(void){
	printf("fun()called from a static library");
}

