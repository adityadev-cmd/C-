#ifndef MESSAGE_H
#define MESSAGE_H
class message {
public:
void printMessage();
};
#endif //Message_H
