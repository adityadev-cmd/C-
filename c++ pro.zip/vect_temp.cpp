#include<bits/stdc++.h>
using namespace std;

template <typename T>
struct Node {
	T data;
	Node *next,*prev;
};
template <class T>
class Nodelist {
	private :
		Node<T>*first;
	public:
		Nodelist(){
			first = NULL;
		}
	void additem(T d);
	void display();
	void del();
	
};

template <class T>
void Nodelist<T> :: display(){
	Node<T>*cur = first;
	while(cur!=NULL){
		cout<<cur->data<<" " ;
		cur= cur->next;
	}
}

template <class T>
void Nodelist<T> :: additem(T d){
	Node<T>*newNode =new Node<T>;
	Node<T>*last =first;
	newNode->next =NULL;
	newNode->data =d;

	if (first ==NULL){
		newNode ->prev = NULL;
		first=newNode;
		return ;
	}

	while(last ->next!=NULL)
	 last=last->next;
		last->next=newNode ;
		newNode->prev=last;

	return;
}

template <class T>
void Nodelist<T> :: del(){
	Node<T> *temp,*temp2 ;
	while(temp->next!=NULL)
		temp =temp->next;

	temp2 = temp->prev;
	temp2->next = temp->next;
	free(temp);

}
int main(){
	Nodelist<int>n;
	n.additem(5);
	n.additem(4);
	n.additem(3);
	n.additem(2);
	n.additem(1);
	n.display();
	cout<<endl;
	n.del();
	n.display();
	cout<<endl;

	Nodelist<char>ni;
	ni.additem('a');
	ni.additem('b');
	ni.additem('c');
	ni.additem('d');
	ni.display();
	ni.del();
	cout<<endl;
	ni.display();


	return 0;
}




