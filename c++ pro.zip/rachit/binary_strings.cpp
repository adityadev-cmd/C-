#include<bits/stdc++.h>
using namespace std ;   //// given n . construct binary values of all possible combinations in ascending order 

void printa(int n, int arr[]){
  for (int i=0;i<n;i++)
	  cout<<arr[i]<<" ";
  cout<<endl;

}
void APC(int n,int arr[],int i){
	if (n==i){
		printa(n,arr);
		return ;
	}

	arr[i]=0;
	APC(n,arr,i+1);
	arr[i]=1;	APC(n,arr,i+1);
}

int main(){
	int n = 4 ;
	int arr[n];

	APC(n,arr,0);
	return 0;
}
