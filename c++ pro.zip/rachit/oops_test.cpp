#include<bits/stdc++.h>
using namespace std;

class A {
	public  :
	static int x;
		A(){
		}
		~A(){
		}

		void *operator new(size_t sz){x++;}
		void *operator delete (){
			x--;}
};

int A::x =0;
int main(){

   A a,b,c; ///local -stack
   A d,e;
    ///dynamic ---heap-
   
  // A* ptr = (A*)malloc(sizeof(A));///allocates but didnit call the constructor 
   A *ptr = new A;   ///both allocate and call constructor/
   A *ptr2 =new A;
   //	free (ptr);
   	delete(ptr);

   cout<<A::x<<endl;
	return 0;
}
