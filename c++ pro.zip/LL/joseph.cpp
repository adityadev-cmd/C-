#include<bits/stdc++.h>
using namespace std;
struct Node {
	int data;
	struct node *next;
};

void joseph(struct Node *head){
 	struct Node *p,*q;
	p=q = (struct Node*)malloc(sizeof(struct Node));

}
int main(){

   return 0;
}





