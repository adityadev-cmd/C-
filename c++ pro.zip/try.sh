man sudo
echo "hello world"
touch ganna.text

