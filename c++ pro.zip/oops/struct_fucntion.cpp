#include<bits/stdc++.h>
using namespace std;  ////how to pass and return struct from function///

struct employee{
 	int id;
	char Name[20];
	int age;
	long salary;
};

void fun(struct employee*);
int main(){
	employee emp = {'1',"chacha",25,25000};
	fun(&emp);
	return 0;
}

void fun(struct employee *e){
	cout<<e->id<<endl;
	cout<<e->Name<<endl;
	cout<<e->age<<endl;
	cout<<e->salary<<endl;
}



