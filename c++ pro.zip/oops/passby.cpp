#include<bits/stdc++.h>
using namespace std;

void swap(int *x,int *y){
	int z;
	z = *x;
	*x = *y;
	*y =z;
}

void swap(int &a,int &b){
	int z = a;
	a=b;
	b=z;
}
int main(){
  int a=10,b=15;
  swap(&a,&b);
  cout<<a<<" "<<b<<endl;
  swap(a,b);
  cout<<a<<" "<<b<<endl;
 // swap(a,b);
 // cout<<a<<" "<<b<<endl;
  return 0;
}
  
