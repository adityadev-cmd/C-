#include<bits/stdc++.h>
using namespace std;

struct base {
	public :
		int x;
};

struct derived:base {};

int main(){

	derived o;
    cout<<o.x=20<<endl;
	return 0;
}
