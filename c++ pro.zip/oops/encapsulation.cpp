#include<bits/stdc++.h>
using namespace std;

class base {
	private :
		int x;
	public :
		void set(int k){
			x = k;
		}
		void print(){
			cout<<x<<endl;
		}
};

int main(){
	base o;
	o.set(5);
	o.print();
	return 0;
}
