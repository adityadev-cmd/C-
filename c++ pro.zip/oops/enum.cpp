#include<bits/stdc++.h>
using namespace std;
enum day{sunday=1,monday,tuesday,wednesday=5,thursday,friday=10,saturday};

int main(){
  enum day d= thursday;
   cout<<d<<endl;

	return 0;
}
