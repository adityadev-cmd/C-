#include<bits/stdc++.h>
using namespace std;

class myclass {
	private:
		int a;
	public:
		int b;
	protected:
		int c;
};
class derived :: public myclass {
	void fun(){
		int a=10;  //not allowed
		int b=20;  ///allowed
		int c=30;  //allowed
	}


};


int main(){
     myclass o;
     o.a =10;  // not alowed
     o.b=20;   //not  allowed
     o.c=30;   //allowed

	return 0;
}
