#include<bits/stdc++.h>
using namespace std;

class circle {
    private:
	  //  int radius;
     public :
	 double radius;
	 double area(){
		 return 3.14*radius*radius ;
	 }
};
int main(){
	circle o;
	o.radius= 5.5;
	cout<<o.radius<<endl;
	cout<<o.area()<<endl;
	return 0;
}
