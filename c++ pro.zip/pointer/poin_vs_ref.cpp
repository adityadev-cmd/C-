#include<bits/stdc++.h>
using namespace std;
//////POINTER VERSES REFENRCE DIFFERNCE IN CPP

void swap(int *x,int *y){
	int z = *x;
	*x = *y;
	*y=z;
}

void swap(int &x,int &y){
	int z = x;
	x=y;
	y=z;
}

int main(){

	int a=10,b=20;
	int *p1 = &a,*p2;
	p2 = &b;
	cout<<*p1<<" "<<*p2<<endl;
	swap(p1,p2);
	cout<<*p1<<" "<<*p2<<endl;
	cout<<a<<" "<<b<<endl;
	cout<<endl;
	
	a=10,b=20;
	int &ref= a,&ref1;
	 ref1=b;
	cout<<ref<<" "<<ref1<<endl;
	swap(ref,ref1);
	cout<<ref<<" "<<ref1<<endl;
	cout<<a<<" "<<b<<endl;

	return 0;
}
