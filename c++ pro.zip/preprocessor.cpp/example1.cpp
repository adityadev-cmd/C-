#include<bits/stdc++.h>
using namespace std;

#include "person_class.cpp"

int main(){
	person p("aditya",23);
	p.display();



	return 0;
}

