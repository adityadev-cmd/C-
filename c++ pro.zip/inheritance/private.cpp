#include<bits/stdc++.h>
using namespace std;

class Base {
	public :int a;
	protected:int b;
	private :int c;
};

class derived :private Base {
	void function(){
		a=10;
		b=20;
		c=30;
	}
};

class derived2 : public derived {
	void fun (){
		int a=10;
		int b=20;
		int c=30;
	}
};

int main(){
	derived o;
	o.a=10;
	o.b=20;
	o.c=30;
	return 0;
}

