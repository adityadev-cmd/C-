#include<bits/stdc++.h>
#include "basic.h"
using namespace std;

int main(){
cout<<"addition"<<" "<<add(10,20);
cout<<"subtract"<<" "<<sub(123,50);
return 0;
}

