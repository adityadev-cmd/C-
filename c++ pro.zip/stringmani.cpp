#include<bits/stdc++.h>
using namespace std;

void isdigit(string s){
	int n=s.length();int c=0;
	for (int i=0;i<n;i++){
		if (s[i]>='0'&&s[i]<='9')c++;
	}
	if (c==n) cout<<"digits"<<endl;
	else if (c<n&& c>0)cout<< "alphanumeric"<<endl;
	else if (c==0)cout<< "string"<<endl;
}

int compares(string s,string s1){
	int n = s.length(),m=s1.length(),i=0,flag=0;
	if(n==m){
	while(s[i]&&s1[i]){
	if(s[i]!=s1[i])flag=1;
	}
	}
	else return 0;
	if (flag==0) return 1;
	else return 0;
}

int len(string s){
	int i=0;
	while(s[i]){
	i++;}
	return i;
}

void swap(char *str1, char *str2){
char *temp;
temp = str1;
str1 = str2;
str2= temp;
}

void reverse(string s){
	int start=0,end=s.length()-1;
	char temp;
	while(start<end){
	temp = s[start];
	s[start]=s[end];
	s[end]=temp;
	start++;
	end--;
	}	
	cout<<s<<endl;
}

int main(){
string s,s1;
cin>>s;
cin>>s1;




int n = len(s);
cout<<"the length of string is "<<n<<endl;
reverse(s);
cout<<endl;
swap(s,s1);
cout<<s<<" "<<s1<<" "<<endl;
isdigit(s);

int ans = compares(s,s1);
if (ans==1)cout<<"same strings"<<endl;
else cout<<"different strings"<<endl;

return 0;
} 
