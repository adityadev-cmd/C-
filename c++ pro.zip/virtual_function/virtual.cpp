#include<bits/stdc++.h>
using namespace std;

class a {
	int a;
	public :
	 void gear(){
	cout <<"in base class"<<endl;
	}
	void show(){
		cout<<"print in base class "<<endl;
	}
};

class b :public a {
      public :
	      void gear (){
	       cout<<"in derived class"<<endl;
       }
       void show(){
	       cout<<"print in derievd class"<<endl;
       }
};

int main(){
	
	a *p,o1;
	
	b o;   
	p=&o; //allowed

	p->show();   ///binding in compile time 	
	p->gear();  ////binding in run time 
	
	cout<<endl;

	p=&o1;
	p->show();
	p->gear();
	cout<<endl;

	return 0;
}
